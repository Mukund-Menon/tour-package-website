import HomePage from './home';
import './App.css';

function App() {
  return (
    <div className="App">
        <HomePage/>
    </div>
  );
}

export default App;
